#include"Entity.h"

class Physics
{
public:

	bool IsClose(const Entity& ent1,const Entity& ent2);
	void MoveEntity(Entity& ent);


};