#include<iostream>
#include"Game.h"

/*/////////////////////////////////////////////////////////////
Repository in GitHub : https://github.com/toshle05/GodSimulator
*//////////////////////////////////////////////////////////////

int main()
{
	Game* game = new Game;

	game->Run();
	

	system("pause");
	return 0;
}